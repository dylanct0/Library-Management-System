package bookManager;

import java.util.ArrayList;

public class Library {
 // Array/constructor to store all books
 private ArrayList<Book> books;
 public Library() {
     this.books = new ArrayList<>();
 }

 // Adds a new book and doesn't allow duplicates
 public void addBook(Book book) {
     if (!books.contains(book)) {
         books.add(book);
     }
 }

 // Removes a book from the library if it exists
 public void removeBook(String title) {
     books.removeIf(book -> book.getTitle().equalsIgnoreCase(title));
 }

 // Displays all books in the library
 public void displayBooks() {
     for (Book book : books) {
         System.out.println(book);
     }
 }

 // Searches for a book by its title and returns it.
 public Book searchBook(String title) {
     for (Book book : books) {
         if (book.getTitle().equalsIgnoreCase(title)) {
             return book;
         }
     }
     return null;
 }
}