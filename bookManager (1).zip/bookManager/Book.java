package bookManager;

//Represents a book in the library.
public class Book {
 // The title of the book
 private String title;
 // The author of the book
 private String author;
 // Whether the book is currently available for borrowing
 private boolean isAvailable;

 // Constructor to initialize a book with its title and author
 public Book(String title, String author) {
     this.title = title;
     this.author = author;
     this.isAvailable = true;
 }

 // Getter method to retrieve the title of the book
 public String getTitle() {
     return title;
 }

 // Getter method to retrieve the author of the book
 public String getAuthor() {
     return author;
 }

 // Getter method to check if the book is available for borrowing
 public boolean isAvailable() {
     return isAvailable;
 }

 // Method to mark the book as borrowed
 public void borrowBook() {
     this.isAvailable = false;
 }

 // Method to mark the book as returned
 public void returnBook() {
     this.isAvailable = true;
 }

 // Overrides the toString method to provide a user-friendly string representation of the book
 @Override
 public String toString() {
     return title + " by " + author + " - " + (isAvailable ? "Available" : "Checked Out");
 }
}