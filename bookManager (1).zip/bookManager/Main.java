package bookManager;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a new library and a member
        Library library = new Library();
        Member member = new Member("Alice");
        Scanner scanner = new Scanner(System.in);

        // Add some initial books to the library
        System.out.println("Adding books to the library...");
        library.addBook(new Book("The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book("1984", "George Orwell"));

        // Main program loop
        while (true) {
            System.out.println("Library Management System");
            System.out.println("1. Display Books");
            System.out.println("2. Search Book");
            System.out.println("3. Borrow Book");
            System.out.println("4. Remove Book");
            System.out.println("5. Add Book");
            System.out.println("6. Return Book");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    // Display all books in the library
                    library.displayBooks();
                    break;
                case 2:
                    // Search for a book by its title
                    System.out.print("Enter book title to search: ");
                    String searchTitle = scanner.nextLine();
                    Book foundBook = library.searchBook(searchTitle);
                    if (foundBook != null) {
                        System.out.println("Book found: " + foundBook);
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 3:
                	 // Borrows book
                    System.out.print("Enter book title to borrow: ");
                    String borrowTitle = scanner.nextLine();
                    member.borrowBook(library, borrowTitle);
                    break;
                case 4:
                    // Remove book prompt
                    System.out.print("Enter book title to remove: ");
                    String removeTitle = scanner.nextLine();
                    library.removeBook(removeTitle);
                    System.out.println("Book removed.");
                    break;
                case 5:
                	 // Add book prompt
                    System.out.print("Enter book title: ");
                    String addTitle = scanner.nextLine();
                    System.out.print("Enter book author: ");
                    String addAuthor = scanner.nextLine();
                    library.addBook(new Book(addTitle, addAuthor));
                    System.out.println("Book added.");
                    break;
                case 6:
                    // Returns book
                    System.out.print("Enter book title to return: ");
                    String returnTitle = scanner.nextLine();
                    member.returnBook(library, returnTitle);
                    System.out.println(returnTitle + " has been successfully returned.");
                    break;
                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}