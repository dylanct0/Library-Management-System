package bookManager;

public class Member {
    // Name of the member
    private String name;

    // Constructor to create a new member with a given name
    public Member(String name) {
        this.name = name;
    }

    // Returns a borrowed book to the library
    public String returnBook(Library library, String title) {
        Book book = library.searchBook(title);
        if (book != null && !book.isAvailable()) {
            book.returnBook();
            return title + " has been returned.";
        } else {
            return "Book has not been borrowed.";
        }
    }
    
 // Borrows a book from the library if it's available
    public String borrowBook(Library library, String title) {
        Book book = library.searchBook(title);
        if (book != null && book.isAvailable()) {
            book.borrowBook();
            return title + " has been borrowed.";
        } else {
            return "Book is being used.";
        }
    }
}

